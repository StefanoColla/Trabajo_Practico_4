package punto2tp3;

/** @author Colla Stefano-Mena Hernan */
public class MedicoTemporal extends Medico {
    private Contrato contrato;
    
    public MedicoTemporal(int documento,String nombre,int horasTrabajadas,int horasExtras){
        super();
        contrato=new Contrato(horasTrabajadas,horasExtras);
        this.setDocumento(documento);
        this.setNombre(nombre);
        calcSueldo();
    }

    @Override
    public void calcSueldo() {
       this.sueldo=(contrato.getHorasExtras()+contrato.getHorasTrabajadas())*this.SUELDOBASE;
    }
     public double getSueldo(){
        return this.sueldo;
    }
     public String getEspecialidad() {
        return especialidad;
    }

   
    public void setEspecialidad(String especialidad) {
        this.especialidad = especialidad;
    }

   
    public String getFechaIngreso() {
        return fechaIngreso;
    }

 
    public void setFechaIngreso(String fechaIngreso) {
        this.fechaIngreso = fechaIngreso;
    }

   
    public String getFechaBaja() {
        return fechaBaja;
    }
    
    public void setFechaBaja(String fechaBaja) {
        this.fechaBaja = fechaBaja;
    }

    @Override
    public String toString() {
        return "MedicoTemporal{" + "nombre=" + nombre + ", documento=" + documento + ", sueldo=" + sueldo + '}';
    }
    
}
