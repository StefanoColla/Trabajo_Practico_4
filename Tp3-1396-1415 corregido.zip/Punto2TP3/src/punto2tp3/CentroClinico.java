package punto2tp3;

import java.util.LinkedList;
import java.util.List;

/** @author Colla Stefano-Mena Hernan */
public class CentroClinico {

  
    public static void main(String[] args) {
       List <Persona> personas= new <Persona>LinkedList();
       MedicoPermanente p2 = new MedicoPermanente("Pedro",5,7,12);
       Enfermedad e1 = new Enfermedad("Permanente","Cancer",2);
       Enfermedad e2 = new Enfermedad("Temporal","Resfrio",4);
       Enfermedad e3 = new Enfermedad("Permanente","SIDA",6);
       Paciente p1 = new Paciente("Juan",2,"A+",e2,"2-4-18",17,p2);
       p1.addEnfermedad(e1);
       p1.addEnfermedad(e3);
       p1.addMedicamento("Ibuprofeno");
       p1.addMedicamento("Decadron");
       p1.addMedicamento("Bayaspirina");
       
       MedicoTemporal p3 = new MedicoTemporal(6,"Jose",4,4);
       personas.add(p1);
       personas.add(p2);
       personas.add(p3);
       System.out.println("Personas presentes en el centro clinico:");
       for(Persona elemento:personas){
           System.out.print(elemento + "\n");
       }
       p1.mostrarTurno();
       p1.ordenarEnfermedades();
       p1.mostrarEnfermedades();
       p1.mostrarMedicamentos();
       
    }
    
}
