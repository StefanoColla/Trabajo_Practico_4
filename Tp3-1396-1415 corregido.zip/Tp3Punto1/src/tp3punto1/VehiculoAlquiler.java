
package tp3punto1;



/**
 *
 * @author usuario
 */
public interface VehiculoAlquiler {
    
    
    public abstract void precioAlquilerPasajero();
    
    
    
}
