
package tp3punto1;



/**
 *
 * @author usuario
 */
public interface VehiculoVenta {
    
    
    public abstract void precioVenta();
    
    
           
    
}
