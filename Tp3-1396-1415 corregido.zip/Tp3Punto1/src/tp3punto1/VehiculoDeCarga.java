
package tp3punto1;

/**
 *
 * @author usuario
 */
public abstract class VehiculoDeCarga extends Vehiculo{
    private Float kilometrosDeUso;

    public VehiculoDeCarga(Float kilometrosDeUso, String marca, String patente, float precioBase) {
        super(marca, patente, precioBase);
        this.kilometrosDeUso = kilometrosDeUso;
    }

   

    public Float getKilometrosDeUso() {
        return kilometrosDeUso;
    }

    public void setKilometrosDeUso(Float kilometrosDeUso) {
        this.kilometrosDeUso = kilometrosDeUso;
    }
    
    
    
    
}
