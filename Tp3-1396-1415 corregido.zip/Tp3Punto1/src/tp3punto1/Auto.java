
package tp3punto1;

/**
 *
 * @author usuario
 */
public  abstract class Auto extends VehiculoDePasajero{
    private float utilidad;

    public Auto(float utilidad, String marca, String patente, float precioBase) {
        super(marca, patente, precioBase);
        this.utilidad = utilidad;
    }


    

   
    

    public float getUtilidad() {
        return utilidad;
    }
    

   

   
    


   


   

   
    
    
    

    
}
