
package tp3punto1;


/**
 *
 * @author usuario
 */
public class Minibus extends VehiculoDePasajero implements VehiculoAlquiler{

    public Minibus(String marca, String patente, float precioBase) {
        super(marca, patente, precioBase);
    }

    

    @Override
    public void precioAlquilerPasajero() {
         
        this.setCostoVehiculo(this.getPrecioBase()+((this.getCantPlaza()*250)*this.getCantDias()));
        
    }

    @Override
    public String toString() {
        return "Minibus{" +"Marca: "+this.getMarca()+"  Patente: "+this.getPatente()+"  Precio: "+this.getCostoVehiculo();
    }
    

 
    
}
