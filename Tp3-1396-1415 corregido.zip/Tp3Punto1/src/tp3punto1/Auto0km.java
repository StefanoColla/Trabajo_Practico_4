
package tp3punto1;



/**
 *
 * @author usuario
 */
public class Auto0km extends Auto implements VehiculoVenta{
    private float aireacondicionado;
    private float levantaCristalesElectrico;
    private float alarma;

    public Auto0km(float utilidad, String marca, String patente, float precioBase) {
        super(utilidad, marca, patente, precioBase);
    }

    

    
    
   
    
    

   

    public float getAireacondicionado() {
        return aireacondicionado;
    }

    public void setAireacondicionado(float aireacondicionado) {
        this.aireacondicionado = aireacondicionado;
    }

    public float getLevantaCristalesElectrico() {
        return levantaCristalesElectrico;
    }

    public void setLevantaCristalesElectrico(float levantaCristalesElectrico) {
        this.levantaCristalesElectrico = levantaCristalesElectrico;
    }

    public float getAlarma() {
        return alarma;
    }

    public void setAlarma(float alarma) {
        this.alarma = alarma;
    }

    
    public void calcularComponentes(){
        this.setAireacondicionado(this.getPrecioBase()*2/100);
        this.setLevantaCristalesElectrico(this.getPrecioBase()*5/100);
        this.setAlarma(this.getPrecioBase()*1/100);
    }
    
    

    

    
 
    @Override
    public String toString() {
        return "Auto0km{"+"   Marca: "+this.getMarca()+"  Patente: "+this.getPatente()+"  Precio: "+this.getCostoVehiculo();
    }

      @Override
    public void precioVenta() {
        
        this.setCostoVehiculo(this.getPrecioBase()+(this.getUtilidad()*50/100)+this.getAireacondicionado()+this.getAlarma()+this.getLevantaCristalesElectrico());
        
    }
    

    

    

   
   
   
    
    
}
