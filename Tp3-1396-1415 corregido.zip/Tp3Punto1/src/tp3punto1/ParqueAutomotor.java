
package tp3punto1;


import java.util.ArrayList;


/**
 *
 * @author Mena Hernan--Colla Stefano
 */
public class ParqueAutomotor {

    
    public static void main(String[] args) {
         ArrayList <VehiculoVenta> vehiculoVenta = new <VehiculoVenta> ArrayList();
         ArrayList <VehiculoAlquiler> vehiculoAlquiler = new <VehiculoAlquiler> ArrayList();
         
        
        AutoUsado usado = new AutoUsado(1238.00f,"Ford KA","ER 567 PO",340.80f);
        usado.setCantDias(7);
        usado.setCantPlaza(5);
        usado.precioVenta();
        
        
        if(vehiculoVenta.equals(usado)){
            vehiculoVenta.add(usado);
        }
        else{
            vehiculoAlquiler.add(usado); 
        }
        AutoUsado usado2 = new AutoUsado(1238.00f,"Ford KA","JK 998 LO",67988.67f);
        usado2.precioVenta();
        usado2.setCantDias(6);
        usado2.setCantPlaza(4);
        if(vehiculoAlquiler.equals(usado2)){
            vehiculoAlquiler.add(usado2);
        }
        else{
            vehiculoVenta.add(usado2);
        }
        Auto0km nuevo = new Auto0km(1238.00f,"Ford Fiesta","AD 566 JK",235657.80f);
        nuevo.calcularComponentes();
        nuevo.precioVenta();
        vehiculoVenta.add(nuevo);
        
        Minibus  mini = new Minibus("Mercedes Sprinter","TH 567 NH",340.80f);
        mini.setCantDias(9);
        mini.setCantPlaza(7);
        mini.precioAlquilerPasajero();
        vehiculoAlquiler.add(mini);
        
        Camioneta cami = new Camioneta(50.800f,"Toyota Hilux","GH 777 MN",300.00f);
        cami.precioAlquilerPasajero();
        vehiculoAlquiler.add(cami);
        
        Camioneta camioneta = new Camioneta(49.900f,"Ford Ranger","DV 822 JJ",300.00f);
        camioneta.precioAlquilerPasajero();
        vehiculoAlquiler.add(camioneta);
        
        Camion camion1 = new Camion(34.700f,"Iveco Stralis","CA 511 VB",300.00f);
        camion1.precioAlquilerPasajero();
        
        System.out.println("\tVEHICULOS EN VENTA");
        for(VehiculoVenta vehiculo : vehiculoVenta){
            System.out.println(vehiculo+"\n");
       
        }
        System.out.println("\tVEHICULO EN ALQUILER");
        for(VehiculoAlquiler vehiculo : vehiculoAlquiler){
            System.out.println(vehiculo+"\n");
            
        }
        
        
       
               
        
    }
    
}
