
package tp3punto1;



/**
 *
 * @author Mena Hernan y Colla Stefano
 */
public class AutoUsado extends Auto implements VehiculoVenta,VehiculoAlquiler{

    public AutoUsado(float utilidad, String marca, String patente, float precioBase) {
        super(utilidad, marca, patente, precioBase);
    }

   
    


      @Override
    public void precioVenta() {
        
        this.setCostoVehiculo(this.getPrecioBase()+(this.getUtilidad()*35/100));
        
    }

    @Override
    public void precioAlquilerPasajero() {
       
        
        this.setCostoVehiculo(this.getPrecioBase()+((50*this.getCantPlaza())*this.getCantDias()));
    }

   
    @Override
    public String toString() {
        return "AutoUsado{"+"   Marca: "+this.getMarca()+"  Patente: "+this.getPatente()+"  Precio: "+this.getCostoVehiculo();
    }

   

    

    
   
   
}
