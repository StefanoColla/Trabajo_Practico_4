
package tp3punto1;

/**
 *
 * @author usuario
 */
public abstract class VehiculoDePasajero extends Vehiculo{
    private int cantPlaza;
    private int cantDias;

    public VehiculoDePasajero(String marca, String patente, float precioBase) {
        super(marca, patente, precioBase);
    }

  

    public int getCantDias() {
        return cantDias;
    }

    public void setCantDias(int cantDias) {
        this.cantDias = cantDias;
    }

  

    public int getCantPlaza() {
        return cantPlaza;
    }

    public void setCantPlaza(int cantPlaza) {
        this.cantPlaza = cantPlaza;
    }
    
    
    
    
    
    
}
