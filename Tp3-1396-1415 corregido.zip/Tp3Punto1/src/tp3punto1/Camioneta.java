
package tp3punto1;

/**
 *
 * @author usuario
 */
public class Camioneta extends VehiculoDeCarga implements VehiculoAlquiler{

    public Camioneta(Float kilometrosDeUso, String marca, String patente, float precioBase) {
        super(kilometrosDeUso, marca, patente, precioBase);
    }

    @Override
    public void precioAlquilerPasajero() {
        if(this.getKilometrosDeUso()<=50){
            this.setCostoVehiculo(this.getPrecioBase());
        }
        else{
            this.setCostoVehiculo(20*this.getKilometrosDeUso());
        }
    }

    @Override
    public String toString() {
        return "Camioneta{" +"Marca: "+this.getMarca()+"  Patente: "+this.getPatente()+"  Precio: "+this.getCostoVehiculo();
    }
    

    
    
    
    
    

}
