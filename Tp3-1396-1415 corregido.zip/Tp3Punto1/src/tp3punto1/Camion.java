
package tp3punto1;

/**
 *
 * @author usuario
 */
public class Camion extends VehiculoDeCarga implements VehiculoAlquiler{

    public Camion(Float kilometrosDeUso, String marca, String patente, float precioBase) {
        super(kilometrosDeUso, marca, patente, precioBase);
    }

    @Override
    public void precioAlquilerPasajero() {
        if(this.getKilometrosDeUso()<=50){
            this.setCostoVehiculo(this.getPrecioBase()+200);
        }
        else{
            this.setCostoVehiculo((20*this.getKilometrosDeUso())+200);
        }
    }

   

   
    
}
