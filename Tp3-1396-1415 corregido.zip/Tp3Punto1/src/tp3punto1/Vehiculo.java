
package tp3punto1;



/**
 *
 * @author usuario
 */
public abstract class Vehiculo {
   
    private String marca;
    private String patente;
    private float precioBase;
    private float costoVehiculo;

    public Vehiculo(String marca, String patente, float precioBase) {
        this.marca = marca;
        this.patente = patente;
        this.precioBase = precioBase;
    }

    

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getPatente() {
        return patente;
    }

    public void setPatente(String patente) {
        this.patente = patente;
    }

    public float getPrecioBase() {
        return precioBase;
    }

    public void setPrecioBase(float precioBase) {
        this.precioBase = precioBase;
    }

    public float getCostoVehiculo() {
        return costoVehiculo;
    }

    public void setCostoVehiculo(float costoVehiculo) {
        this.costoVehiculo = costoVehiculo;
    }

   
    
  
    
    
    
}
